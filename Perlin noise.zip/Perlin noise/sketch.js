// Perlin Noise generator
// Iskander Baizrakhman
// 3/6/2026
//
// Extra for Experts:
// - describe what you did to take this project "above and beyond"
let time = 5;
let rectWidth = 1;
let canvaswidth = 500;
let offset = 0;
function setup() {
  createCanvas(canvaswidth, 500);
}




function falg(x,y){
  fill(255,0,0)
  //circle(x,500-y,15)
  rect(x,490-y,2,15)
  rect(x,490-y,7,5)
}

function average(x,y){
  fill(255,0,0)
  rect(x,y,500,3)
}

function noiseGen(){
  let highestheight = 0
  let highestX = 0
  strokeWeight(rectWidth)
  //using a loop to make a number of rectangles with random height.
  for(let x = 0; x < width; x+=rectWidth){
    //generate random negative height.
    //replace this with noise()
    //let rectHeight = random(0, height*0.75);
    let rectHeight = noise(time) * 100;
    time += 0.1

    rect(x,height,rectWidth,-rectHeight);
    if (rectHeight >= highestheight){
      //which line is the highest
      highestheight = rectHeight
      highestX = x
    }
  }

  falg(highestX, highestheight)
  average(0, highestheight+375)

}



function draw() {
  //locks in this as a starting point (seed 25 from random, the next one will be seed 26, etc.)
  //noiseSeed(10);
  time = 1 + offset
  //stabilizer, still gets random results each frame.
  background(220);
  noiseGen()
  //falg()
  if (keyIsDown(LEFT_ARROW)){
    offset -= 0.5
  } else if (keyIsDown(RIGHT_ARROW)){
    offset += 0.5
  }
}
